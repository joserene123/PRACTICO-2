#include "StdAfx.h"
#include "Menor.h"


Menor::Menor(void)
{
	Vector[n]=0;
	Tamano=0;
}
int Menor::Get_Tamano()
{
	return Tamano;
}
void Menor::Set_Tamano(int tam)
{
	Tamano=tam;
}
double Menor::Get_Vector(int pos)
{
	return Vector[pos];
}
void Menor::Set_Vector(double valor, int pos)
{
	Vector[pos]=valor;
}
double Menor::Calcular(int pos)
{double men=Vector[0];
 for(int i=0; i<pos; i++)
    {if(men>=Vector[i])
	  {
		  men=Vector[i];
	  }
	}
 return men;
}