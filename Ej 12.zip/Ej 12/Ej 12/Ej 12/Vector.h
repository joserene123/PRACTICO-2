#pragma once
#include "iostream"
#define N 50
using namespace std;
 class Vector
{
private:
	int V[N];
	int tamano;
public:
	Vector(void);
	void Set_V(int posicion, int elemento); //traigo posicion y elemento del form, para poder decir cuanto vale V
	int Get_V(int posicion); //traigo posicion para poder devolver V[pos] y en la posicion que se desea 
    void Set_tamano(int tam);//traigo el tam del form para asignarselo a tamano
	int Get_tamano();
    int repetidos();

};

