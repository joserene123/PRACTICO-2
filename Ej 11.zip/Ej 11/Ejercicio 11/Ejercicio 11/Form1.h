#pragma once
#include <iostream>
#include <conio.h>
#include "Contar.h"
#include <msclr\marshal_cppstd.h>


namespace Ejercicio11 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	Contar Cont1;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::Button^  btnTamano;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtVal;
	private: System::Windows::Forms::Button^  btnVal;
	private: System::Windows::Forms::DataGridView^  grilla;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtPos;
	private: System::Windows::Forms::TextBox^  txtNeg;
	private: System::Windows::Forms::TextBox^  txtCero;
	private: System::Windows::Forms::Button^  btnObtener;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->btnTamano = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtVal = (gcnew System::Windows::Forms::TextBox());
			this->btnVal = (gcnew System::Windows::Forms::Button());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtPos = (gcnew System::Windows::Forms::TextBox());
			this->txtNeg = (gcnew System::Windows::Forms::TextBox());
			this->txtCero = (gcnew System::Windows::Forms::TextBox());
			this->btnObtener = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(26, 20);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(78, 17);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(100, 20);
			this->txtTamano->TabIndex = 1;
			// 
			// btnTamano
			// 
			this->btnTamano->Location = System::Drawing::Point(184, 15);
			this->btnTamano->Name = L"btnTamano";
			this->btnTamano->Size = System::Drawing::Size(75, 23);
			this->btnTamano->TabIndex = 2;
			this->btnTamano->Text = L"Ingresar";
			this->btnTamano->UseVisualStyleBackColor = true;
			this->btnTamano->Click += gcnew System::EventHandler(this, &Form1::btnTamano_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(26, 57);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(31, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Valor";
			// 
			// txtVal
			// 
			this->txtVal->Location = System::Drawing::Point(78, 54);
			this->txtVal->Name = L"txtVal";
			this->txtVal->Size = System::Drawing::Size(100, 20);
			this->txtVal->TabIndex = 4;
			// 
			// btnVal
			// 
			this->btnVal->Location = System::Drawing::Point(184, 52);
			this->btnVal->Name = L"btnVal";
			this->btnVal->Size = System::Drawing::Size(75, 23);
			this->btnVal->TabIndex = 5;
			this->btnVal->Text = L"Ingresar";
			this->btnVal->UseVisualStyleBackColor = true;
			this->btnVal->Click += gcnew System::EventHandler(this, &Form1::btnVal_Click);
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(19, 99);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(141, 150);
			this->grilla->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(172, 112);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(67, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Cantidad de:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(166, 136);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(49, 13);
			this->label4->TabIndex = 8;
			this->label4->Text = L"Positivos";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(166, 166);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(55, 13);
			this->label5->TabIndex = 9;
			this->label5->Text = L"Negativos";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(166, 197);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(34, 13);
			this->label6->TabIndex = 10;
			this->label6->Text = L"Ceros";
			// 
			// txtPos
			// 
			this->txtPos->Location = System::Drawing::Point(221, 133);
			this->txtPos->Name = L"txtPos";
			this->txtPos->Size = System::Drawing::Size(68, 20);
			this->txtPos->TabIndex = 11;
			// 
			// txtNeg
			// 
			this->txtNeg->Location = System::Drawing::Point(221, 163);
			this->txtNeg->Name = L"txtNeg";
			this->txtNeg->Size = System::Drawing::Size(68, 20);
			this->txtNeg->TabIndex = 12;
			// 
			// txtCero
			// 
			this->txtCero->Location = System::Drawing::Point(221, 194);
			this->txtCero->Name = L"txtCero";
			this->txtCero->Size = System::Drawing::Size(68, 20);
			this->txtCero->TabIndex = 13;
			// 
			// btnObtener
			// 
			this->btnObtener->Location = System::Drawing::Point(184, 226);
			this->btnObtener->Name = L"btnObtener";
			this->btnObtener->Size = System::Drawing::Size(75, 23);
			this->btnObtener->TabIndex = 14;
			this->btnObtener->Text = L"Obtener";
			this->btnObtener->UseVisualStyleBackColor = true;
			this->btnObtener->Click += gcnew System::EventHandler(this, &Form1::btnObtener_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(301, 261);
			this->Controls->Add(this->btnObtener);
			this->Controls->Add(this->txtCero);
			this->Controls->Add(this->txtNeg);
			this->Controls->Add(this->txtPos);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->btnVal);
			this->Controls->Add(this->txtVal);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnTamano);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTamano_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=System::Convert::ToInt32(txtTamano->Text);
				 Cont1.Set_tamano(tam);
				 grilla->RowCount=Cont1.Get_tamano();
				 pos=0;
			 }
private: System::Void btnVal_Click(System::Object^  sender, System::EventArgs^  e) {
			 double elem;
			 elem=System::Convert::ToDouble(txtVal->Text);
			 if(Cont1.Llenar(pos,elem))
			 {
				 pos++;
				 grilla->ColumnCount=1;
				 grilla->ColumnCount=Cont1.Get_tamano();
				 double val;
				 for(int i=0;i<Cont1.Get_tamano();i++)
				 {
					 val=Cont1.Get_vector(i);
					 grilla->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val);
				 }
			 }
		 }
private: System::Void btnObtener_Click(System::Object^  sender, System::EventArgs^  e) {
			 int Posi,Nega,Ceros;
			 Posi=Cont1.ContarPosi(Cont1.Get_tamano());
			 Nega=Cont1.ContarNeg(Cont1.Get_tamano());
			 Ceros=Cont1.ContarCero(Cont1.Get_tamano());
			 txtPos->Text=System::Convert::ToString(Posi);
			 txtNeg->Text=System::Convert::ToString(Nega);
			 txtCero->Text=System::Convert::ToString(Ceros);
		 }
};
}

