#include "StdAfx.h"
#include "Vector.h"

using namespace std;


Vector::Vector(void)
{ V[N]=0;
  tamano=0;
}

void Vector::Set_V(int posicion, int elemento) //traigo posicion y elemento del form, para poder decir cuanto vale V
{  V[posicion]=elemento;
}

	int Vector::Get_V(int posicion) //traigo posicion para poder devolver V[pos] y en la posicion que se desea 
	{ return V[posicion];
	}

    void Vector::Set_tamano(int tam)//traigo el tam del form para asignarselo a tamano
	{ tamano=tam;
	}

	int Vector::Get_tamano() //como voy a devolver tamano, no traigo nada del form porque no depende de nada, como el V que necesita una pos
	{ return tamano;
	}

	int  Vector::repetidos() //Hacer que devuelva repetidos,  no env�o V ni tam, porque est�n en mi .h
	{ int aux=0;
      
     
       for (int k=0; k<tamano;k++)
		   {for (int s=k+1;s<tamano;s++)
                 { if (V[k]==V[s])
	                 {aux=V[k];
	                 }
	             }
	  
	   } return aux;

	


		/*int t=0, st;
      int D[50],aux[50],n;
     
       for (int k=0; k<tam;k++)
          { st=0;
            n=V[k];
	        aux[k]=n;
	        for(int j=0;j<tam;j++)
	          { if(aux[j]==n)
	             {st++;
	             }
	          }
	       if(st==1)
	          {D[t]=n;
	            t++;
	          }
          }*/ 
	}
