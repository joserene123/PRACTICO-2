#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#define MAX 10

Vector::Vector(void)
{
	vec[MAX]=0;
	vec2[MAX]=0;
	tamano=0;
}

int Vector::Get_vec(int posicion)
{
	return vec[posicion];
}

void Vector::Set_vec(int elemento, int posicion)
{
	vec[posicion]=elemento;
}

int Vector::Get_vec2(int posicion)
{
	return vec2[posicion];
}

void Vector::Set_vec2(int elemento, int posicion)
{
	vec2[posicion]=elemento;
}


int Vector::Get_tamano()
{return tamano;}
	
void Vector::Set_tamano(int elemento)
{tamano=elemento;
}

void Vector::Ordenar (int tam)
{int aux=tam-1;
for (int i=0;i<tam;i++)
{
vec2[aux-i]=vec[i];

} 


}

