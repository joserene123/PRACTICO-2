#pragma once
#include <iostream>
#include "Encontrar.h"
#include <string>
//#include <msclr\marshal_cppstd.h>



namespace Menor {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	//using namespace msclr;
	Encontrar Dif1;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::Button^  btnVal;
	private: System::Windows::Forms::Button^  btnMen;
	private: System::Windows::Forms::TextBox^  txtTam;
	private: System::Windows::Forms::TextBox^  txtVal;
	private: System::Windows::Forms::TextBox^  txtDif;

	private: System::Windows::Forms::DataGridView^  grilla;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->btnVal = (gcnew System::Windows::Forms::Button());
			this->btnMen = (gcnew System::Windows::Forms::Button());
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->txtVal = (gcnew System::Windows::Forms::TextBox());
			this->txtDif = (gcnew System::Windows::Forms::TextBox());
			this->grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(28, 20);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(28, 68);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(31, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Valor";
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(185, 15);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 2;
			this->btnTam->Text = L"Ingresar";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// btnVal
			// 
			this->btnVal->Location = System::Drawing::Point(185, 63);
			this->btnVal->Name = L"btnVal";
			this->btnVal->Size = System::Drawing::Size(75, 23);
			this->btnVal->TabIndex = 3;
			this->btnVal->Text = L"Ingresar";
			this->btnVal->UseVisualStyleBackColor = true;
			this->btnVal->Click += gcnew System::EventHandler(this, &Form1::btnVal_Click);
			// 
			// btnMen
			// 
			this->btnMen->Location = System::Drawing::Point(185, 110);
			this->btnMen->Name = L"btnMen";
			this->btnMen->Size = System::Drawing::Size(75, 45);
			this->btnMen->TabIndex = 4;
			this->btnMen->Text = L"Diferencia Mayor";
			this->btnMen->UseVisualStyleBackColor = true;
			this->btnMen->Click += gcnew System::EventHandler(this, &Form1::btnMen_Click);
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(89, 17);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(73, 20);
			this->txtTam->TabIndex = 5;
			// 
			// txtVal
			// 
			this->txtVal->Location = System::Drawing::Point(89, 65);
			this->txtVal->Name = L"txtVal";
			this->txtVal->Size = System::Drawing::Size(73, 20);
			this->txtVal->TabIndex = 6;
			// 
			// txtDif
			// 
			this->txtDif->Location = System::Drawing::Point(185, 161);
			this->txtDif->Name = L"txtDif";
			this->txtDif->Size = System::Drawing::Size(75, 20);
			this->txtDif->TabIndex = 7;
			// 
			// grilla
			// 
			this->grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla->Location = System::Drawing::Point(12, 99);
			this->grilla->Name = L"grilla";
			this->grilla->Size = System::Drawing::Size(142, 150);
			this->grilla->TabIndex = 8;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->grilla);
			this->Controls->Add(this->txtDif);
			this->Controls->Add(this->txtVal);
			this->Controls->Add(this->txtTam);
			this->Controls->Add(this->btnMen);
			this->Controls->Add(this->btnVal);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
				 int Tam;
				 Tam=System::Convert::ToInt32(txtTam->Text);
				 Dif1.Set_tamano(Tam);
				 grilla->RowCount=Dif1.Get_tamano();
				 pos=0;

			 }
private: System::Void btnVal_Click(System::Object^  sender, System::EventArgs^  e) {
			 double element;
			 element=System::Convert::ToDouble(txtVal->Text);
			 if(Dif1.Llenar(pos,element))
			 {
				 pos++;
				 grilla->ColumnCount=1;
				 grilla->ColumnCount=Dif1.Get_tamano();
				 double val;
				 for(int i=0;i<Dif1.Get_tamano();i++)
				 {
					 val=Dif1.Get_vector(i);
					 grilla->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val);
				 }
			 }
		 }
		 
private: System::Void btnMen_Click(System::Object^  sender, System::EventArgs^  e) {
			 double M;
			 M=Dif1.BuscarDiferencia(Dif1.Get_tamano());
			 txtDif->Text=System::Convert::ToString(M);
		 }
};
}

