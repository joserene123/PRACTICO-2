#pragma once
#define T 20

class Encontrar
{
private:
	double vec[T];
	int tamano;
public:
	Encontrar(void);
	int Get_tamano();
	void Set_tamano(int tam);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	bool LlenoVector();
	bool VacioVector();
	bool Llenar(int posicion, double elemento);
	double BuscarDiferencia(int tam);
};

