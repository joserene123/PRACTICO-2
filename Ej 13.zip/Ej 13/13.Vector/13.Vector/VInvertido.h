#pragma once
#define MAX 10
class VInvertido
{
private:
	double V[MAX];
	int tamano;
public:
	VInvertido(void);
	double Get_Vector(int posicion);
	void Set_Vector(double elemento, int posicion);
	int Get_Tamano();
	void Set_Tamano(int tam);
	bool Lleno_Vector();
	bool Vacio_Vector();
	bool Ingresar_Vector(double elemento,int posicion);
	void Invertir_Vector();
};

