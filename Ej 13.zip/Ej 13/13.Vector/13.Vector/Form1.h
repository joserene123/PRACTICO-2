#pragma once
#include <iostream>
#include <string>
#include "VInvertido.h"
#include <msclr\marshal_cppstd.h>

namespace My13Vector {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	VInvertido invertido1;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtNumeros;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnInvertirVector;
	private: System::Windows::Forms::DataGridView^  Grilla_Vector;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Vector;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtNumeros = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnInvertirVector = (gcnew System::Windows::Forms::Button());
			this->Grilla_Vector = (gcnew System::Windows::Forms::DataGridView());
			this->Vector = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla_Vector))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(24, 49);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(60, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(24, 109);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(65, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Numeros";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(92, 44);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(90, 22);
			this->txtTamano->TabIndex = 2;
			// 
			// txtNumeros
			// 
			this->txtNumeros->Location = System::Drawing::Point(92, 109);
			this->txtNumeros->Name = L"txtNumeros";
			this->txtNumeros->Size = System::Drawing::Size(90, 22);
			this->txtNumeros->TabIndex = 3;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(217, 44);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 29);
			this->btnDefinir->TabIndex = 4;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(217, 109);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 28);
			this->btnIngresar->TabIndex = 5;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnInvertirVector
			// 
			this->btnInvertirVector->Location = System::Drawing::Point(73, 182);
			this->btnInvertirVector->Name = L"btnInvertirVector";
			this->btnInvertirVector->Size = System::Drawing::Size(108, 40);
			this->btnInvertirVector->TabIndex = 6;
			this->btnInvertirVector->Text = L"Invertir Vector";
			this->btnInvertirVector->UseVisualStyleBackColor = true;
			this->btnInvertirVector->Click += gcnew System::EventHandler(this, &Form1::btnInvertirVector_Click);
			// 
			// Grilla_Vector
			// 
			this->Grilla_Vector->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla_Vector->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Vector});
			this->Grilla_Vector->Location = System::Drawing::Point(333, 37);
			this->Grilla_Vector->Name = L"Grilla_Vector";
			this->Grilla_Vector->RowTemplate->Height = 24;
			this->Grilla_Vector->Size = System::Drawing::Size(222, 323);
			this->Grilla_Vector->TabIndex = 7;
			// 
			// Vector
			// 
			this->Vector->HeaderText = L"Vector";
			this->Vector->Name = L"Vector";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(587, 391);
			this->Controls->Add(this->Grilla_Vector);
			this->Controls->Add(this->btnInvertirVector);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtNumeros);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla_Vector))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTamano->Text);
			 invertido1.Set_Tamano(tam);
			 Grilla_Vector->RowCount=invertido1.Get_Tamano();
			 pos=0;
			 }
	private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elemento;
			 elemento=System::Convert::ToDouble(txtNumeros->Text);
			 if (invertido1.Ingresar_Vector(elemento,pos)) {
				pos++;
				Grilla_Vector->ColumnCount=1;
				Grilla_Vector->RowCount=invertido1.Get_Tamano();
				int i=0; 
				double numero;
				for (i=0;i<invertido1.Get_Tamano();i++)
				{
				numero=invertido1.Get_Vector(i);
				Grilla_Vector->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(numero);
				}
			 }
			 }
private: System::Void btnInvertirVector_Click(System::Object^  sender, System::EventArgs^  e) {
			 invertido1.Invertir_Vector();
			 Grilla_Vector->ColumnCount=1;
			 Grilla_Vector->RowCount=invertido1.Get_Tamano();
			 int i=0;
			 double numero;
			 for(i=0;i<invertido1.Get_Tamano(); i++)
			 {
				 numero=invertido1.Get_Vector(i);
			 Grilla_Vector->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(numero);
		 }
		 }
};
}

