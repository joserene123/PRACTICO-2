#pragma once
#define n 500
class Menor
{private:
 double Vector[n];
 int Tamano;
 public:
	Menor(void);
	int Get_Tamano();
	void Set_Tamano(int tam);
	double Get_Vector(int pos);
	void Set_Vector(double valor, int pos);
	double Calcular(int pos);
};

