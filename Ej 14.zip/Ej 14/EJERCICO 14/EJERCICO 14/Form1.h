#pragma once
#include "Vector.h"
#include <iostream>
#include <msclr\marshal_cppstd.h>
namespace EJERCICO14 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	
	Vector arreglo_reg_notas;
int	pos =0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla_nota;
	protected: 

	protected: 
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnOrdenar;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::TextBox^  txtnota;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla_nota = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnOrdenar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->txtnota = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_nota))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla_nota
			// 
			this->grilla_nota->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_nota->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla_nota->Location = System::Drawing::Point(12, 157);
			this->grilla_nota->Name = L"grilla_nota";
			this->grilla_nota->Size = System::Drawing::Size(386, 144);
			this->grilla_nota->TabIndex = 0;
			this->grilla_nota->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Nota";
			this->Column1->Name = L"Column1";
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(252, 16);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 1;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(252, 67);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 2;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnOrdenar
			// 
			this->btnOrdenar->Location = System::Drawing::Point(174, 119);
			this->btnOrdenar->Name = L"btnOrdenar";
			this->btnOrdenar->Size = System::Drawing::Size(75, 23);
			this->btnOrdenar->TabIndex = 3;
			this->btnOrdenar->Text = L"Ordenar";
			this->btnOrdenar->UseVisualStyleBackColor = true;
			this->btnOrdenar->Click += gcnew System::EventHandler(this, &Form1::btnOrdenar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(23, 22);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Tama�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(23, 77);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(30, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Nota";
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(113, 19);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(100, 20);
			this->txttamano->TabIndex = 6;
			// 
			// txtnota
			// 
			this->txtnota->Location = System::Drawing::Point(113, 69);
			this->txtnota->Name = L"txtnota";
			this->txtnota->Size = System::Drawing::Size(100, 20);
			this->txtnota->TabIndex = 7;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(424, 355);
			this->Controls->Add(this->txtnota);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnOrdenar);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->grilla_nota);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_nota))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {


			  int tam;
			 tam=System::Convert::ToInt32(txttamano->Text);
			 arreglo_reg_notas.Set_tamano(tam);
             grilla_nota->RowCount=arreglo_reg_notas.Get_tamano();
			 pos=0;


		 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {

			  int elemento;
			 elemento=System::Convert::ToInt32(txtnota->Text);
			 if(arreglo_reg_notas.Insertar(elemento, pos))
			 {pos++;
			 grilla_nota->ColumnCount=1;
			 grilla_nota->RowCount=arreglo_reg_notas.Get_tamano();
			 int nota, i=0;
			 for(i=0;i<arreglo_reg_notas.Get_tamano(); i++)
			 {nota=arreglo_reg_notas.Get_vector(i);
			 grilla_nota->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(nota);
			 }
			 }



		 }
private: System::Void btnOrdenar_Click(System::Object^  sender, System::EventArgs^  e) {



			 arreglo_reg_notas.ordenarVector();
			 grilla_nota->ColumnCount=1;
			 grilla_nota->RowCount=arreglo_reg_notas.Get_tamano();
			 int nota, i=0;
			 for(i=0;i<arreglo_reg_notas.Get_tamano(); i++)
			 {nota=arreglo_reg_notas.Get_vector(i);
			 grilla_nota->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(nota);
			 }
		 }
};
}

